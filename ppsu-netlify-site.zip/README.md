# PPSU Game Management – Netlify deploy

## Option A – Live publishing (recommended)
1. Put this folder in a Git repo (GitHub etc.) and import it in Netlify, or run `netlify deploy --prod` with the Netlify CLI.
   (Netlify installs `@netlify/blobs` and builds the function automatically.)
2. Netlify > Site configuration > Environment variables: add `PUBLISH_TOKEN` = a secret of your choice. Redeploy once.
3. Open your site > Administrator > log in > 📤 Publish. Paste the token (saved on that device) and tap Publish now.
   Viewers' pages refresh themselves every ~15 seconds.

## Option B – Static only (drag and drop)
Drag `public/index.html` onto Netlify's Deploys page. Publish then downloads a fresh index.html,
which you drag onto Netlify again to update viewers (not instant).

import { getStore } from "@netlify/blobs";

const H = { "content-type": "application/json", "cache-control": "no-store" };
const j = (o, status = 200) => new Response(JSON.stringify(o), { status, headers: H });

export default async (req) => {
  const store = getStore("ppsu-live");

  if (req.method === "GET") {
    const data = await store.get("snapshot", { type: "text" });
    if (!data) return j({ error: "nothing published yet" }, 404);
    return new Response(data, { headers: H });
  }

  if (req.method === "POST") {
    const token = process.env.PUBLISH_TOKEN;
    if (!token) return j({ error: "PUBLISH_TOKEN is not set in Netlify" }, 500);
    if ((req.headers.get("authorization") || "") !== "Bearer " + token) return j({ error: "unauthorized" }, 401);
    const body = await req.text();
    if (body.length > 4_000_000) return j({ error: "too large" }, 413);
    try {
      const d = JSON.parse(body);
      if (!d || d.v !== 1) throw new Error("bad snapshot");
    } catch {
      return j({ error: "invalid snapshot" }, 400);
    }
    await store.set("snapshot", body);
    return j({ ok: true });
  }

  return j({ error: "method not allowed" }, 405);
};

export const config = { path: "/api/snapshot" };
